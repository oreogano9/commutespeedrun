let lastPosition = "";

const DEFAULT_OVERLAY_SCALE = 1.05;
const DEFAULT_DISPLAY_DURATION = 14;
const DEFAULT_OVERLAY_RADIUS = 14;
const DEFAULT_OVERLAY_AVATAR_SIZE = 25;
const DEFAULT_OVERLAY_GLASSINESS = 24;
const DEFAULT_OVERLAY_DARKNESS = 31;
const DEFAULT_DEBUG_MODE = false;
const DEFAULT_ALLOW_LONG_MESSAGES = false;
const DEFAULT_MAX_MESSAGE_CHARS = 300;
const DEFAULT_EARLY_MODE_ENABLED = false;
const DEFAULT_FOLLOW_PLAYBACK_SPEED = true;
const DEFAULT_EARLY_SECONDS = 5;
const DEFAULT_TIMESTAMP_ACCENT_EFFECT = "rubberband";
const DEFAULT_REVERSE_STACK_ORDER = false;
const DEFAULT_POPUP_DARK_MODE = true;
const DEFAULT_PRIORITY_SCORING_ENABLED = true;
const DEFAULT_PRIORITY_LIKES_WEIGHT = 1;
const DEFAULT_TOP_LIKED_THRESHOLD_PERCENT = 12;
const DEFAULT_HEATMAP_ENABLED = true;
const DEFAULT_HEATMAP_INTENSITY = 500;
const DEFAULT_ROUTING_ENABLED = false;
const DEFAULT_ROUTING_THRESHOLD = 80;
const DEFAULT_ROUTING_SHORT_CORNER = "bottom-left";
const DEFAULT_ROUTING_LONG_CORNER = "top-right";
const DEFAULT_SHOW_LIKES_IN_NOTIFICATIONS = true;

const MIN_OVERLAY_SCALE = 0.5;
const MAX_OVERLAY_SCALE = 3.5;
const MIN_DISPLAY_DURATION = 1;
const MAX_DISPLAY_DURATION = 60;
const MIN_OVERLAY_RADIUS = 0;
const MAX_OVERLAY_RADIUS = 120;
const MIN_OVERLAY_AVATAR_SIZE = 20;
const MAX_OVERLAY_AVATAR_SIZE = 84;
const MIN_OVERLAY_GLASSINESS = 0;
const MAX_OVERLAY_GLASSINESS = 100;
const MIN_OVERLAY_DARKNESS = 0;
const MAX_OVERLAY_DARKNESS = 100;
const MIN_MAX_MESSAGE_CHARS = 1;
const MAX_MAX_MESSAGE_CHARS = 5000;
const MIN_EARLY_SECONDS = 0;
const MAX_EARLY_SECONDS = 60;
const MIN_PRIORITY_LIKES_WEIGHT = 0;
const MAX_PRIORITY_LIKES_WEIGHT = 5;
const MIN_TOP_LIKED_THRESHOLD_PERCENT = 1;
const MAX_TOP_LIKED_THRESHOLD_PERCENT = 50;
const MIN_HEATMAP_INTENSITY = 10;
const MAX_HEATMAP_INTENSITY = 2000;
const MIN_ROUTING_THRESHOLD = 1;
const MAX_ROUTING_THRESHOLD = 5000;

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function deriveDiamondThresholdPercent(topLikedThresholdPercent) {
  const top = clamp(
    Number(topLikedThresholdPercent ?? DEFAULT_TOP_LIKED_THRESHOLD_PERCENT),
    MIN_TOP_LIKED_THRESHOLD_PERCENT,
    MAX_TOP_LIKED_THRESHOLD_PERCENT
  );
  return Math.max(1, Math.floor(top * 0.35));
}

function extractVideoIdFromUrl(url) {
  if (!url) {
    return null;
  }
  try {
    const parsed = new URL(url);
    if (parsed.pathname === "/watch") {
      return parsed.searchParams.get("v");
    }
    if (parsed.pathname.startsWith("/embed/")) {
      return parsed.pathname.substring("/embed/".length);
    }
  } catch (error) {
    return null;
  }
  return null;
}

async function getActiveYouTubeVideoId() {
  const tabGroups = await Promise.all([
    chrome.tabs.query({ active: true, currentWindow: true }),
    chrome.tabs.query({ active: true, lastFocusedWindow: true }),
    chrome.tabs.query({ currentWindow: true })
  ]);

  for (const tabs of tabGroups) {
    for (const tab of tabs || []) {
      const videoId = extractVideoIdFromUrl(tab?.url || "");
      if (videoId) {
        return videoId;
      }
    }
  }

  const allTabs = await chrome.tabs.query({});
  for (const tab of allTabs) {
    const videoId = extractVideoIdFromUrl(tab?.url || "");
    if (videoId) {
      return videoId;
    }
  }
  return null;
}

async function getConfigs() {
  const stored = await chrome.storage.sync.get([
    "active",
    "position",
    "overlayScale",
    "displayDuration",
    "overlayRadius",
    "overlayAvatarSize",
    "overlayGlassiness",
    "overlayDarkness",
    "debugMode",
    "allowLongMessages",
    "maxMessageChars",
    "earlyModeEnabled",
    "followPlaybackSpeed",
    "earlySeconds",
    "timestampAccentEffect",
    "reverseStackOrder",
    "popupDarkMode",
    "priorityScoringEnabled",
    "priorityLikesWeight",
    "topLikedThresholdPercent",
    "heatmapEnabled",
    "heatmapIntensity",
    "routingEnabled",
    "routingThreshold",
    "routingShortCorner",
    "routingLongCorner",
    "showLikesInNotifications"
  ]);

  const isActive = stored?.active !== undefined && stored?.active !== null ? stored.active : true;
  const position = stored?.position || "bottom-left";
  const overlayScale = clamp(
    Number(stored?.overlayScale ?? DEFAULT_OVERLAY_SCALE),
    MIN_OVERLAY_SCALE,
    MAX_OVERLAY_SCALE
  );
  const displayDuration = clamp(
    Number(stored?.displayDuration ?? DEFAULT_DISPLAY_DURATION),
    MIN_DISPLAY_DURATION,
    MAX_DISPLAY_DURATION
  );
  const overlayRadius = clamp(
    Number(stored?.overlayRadius ?? DEFAULT_OVERLAY_RADIUS),
    MIN_OVERLAY_RADIUS,
    MAX_OVERLAY_RADIUS
  );
  const overlayAvatarSize = clamp(
    Number(stored?.overlayAvatarSize ?? DEFAULT_OVERLAY_AVATAR_SIZE),
    MIN_OVERLAY_AVATAR_SIZE,
    MAX_OVERLAY_AVATAR_SIZE
  );
  const overlayGlassiness = clamp(
    Number(stored?.overlayGlassiness ?? DEFAULT_OVERLAY_GLASSINESS),
    MIN_OVERLAY_GLASSINESS,
    MAX_OVERLAY_GLASSINESS
  );
  const overlayDarkness = clamp(
    Number(stored?.overlayDarkness ?? DEFAULT_OVERLAY_DARKNESS),
    MIN_OVERLAY_DARKNESS,
    MAX_OVERLAY_DARKNESS
  );
  const debugMode = Boolean(stored?.debugMode ?? DEFAULT_DEBUG_MODE);
  const allowLongMessages =
    stored?.allowLongMessages === undefined
      ? DEFAULT_ALLOW_LONG_MESSAGES
      : Boolean(stored.allowLongMessages);
  const maxMessageChars = clamp(
    Number(stored?.maxMessageChars ?? DEFAULT_MAX_MESSAGE_CHARS),
    MIN_MAX_MESSAGE_CHARS,
    MAX_MAX_MESSAGE_CHARS
  );
  const earlyModeEnabled = Boolean(stored?.earlyModeEnabled ?? DEFAULT_EARLY_MODE_ENABLED);
  const followPlaybackSpeed = Boolean(
    stored?.followPlaybackSpeed ?? DEFAULT_FOLLOW_PLAYBACK_SPEED
  );
  const earlySeconds = clamp(
    Number(stored?.earlySeconds ?? DEFAULT_EARLY_SECONDS),
    MIN_EARLY_SECONDS,
    MAX_EARLY_SECONDS
  );
  const timestampAccentEffect = String(
    stored?.timestampAccentEffect ?? DEFAULT_TIMESTAMP_ACCENT_EFFECT
  );
  const reverseStackOrder = Boolean(stored?.reverseStackOrder ?? DEFAULT_REVERSE_STACK_ORDER);
  const popupDarkMode = Boolean(stored?.popupDarkMode ?? DEFAULT_POPUP_DARK_MODE);
  const priorityScoringEnabled = Boolean(
    stored?.priorityScoringEnabled ?? DEFAULT_PRIORITY_SCORING_ENABLED
  );
  const priorityLikesWeight = clamp(
    Number(stored?.priorityLikesWeight ?? DEFAULT_PRIORITY_LIKES_WEIGHT),
    MIN_PRIORITY_LIKES_WEIGHT,
    MAX_PRIORITY_LIKES_WEIGHT
  );
  const topLikedThresholdPercent = clamp(
    Number(stored?.topLikedThresholdPercent ?? DEFAULT_TOP_LIKED_THRESHOLD_PERCENT),
    MIN_TOP_LIKED_THRESHOLD_PERCENT,
    MAX_TOP_LIKED_THRESHOLD_PERCENT
  );
  const diamondThresholdPercent = deriveDiamondThresholdPercent(topLikedThresholdPercent);
  const heatmapEnabled = Boolean(stored?.heatmapEnabled ?? DEFAULT_HEATMAP_ENABLED);
  const heatmapIntensity = clamp(
    Number(stored?.heatmapIntensity ?? DEFAULT_HEATMAP_INTENSITY),
    MIN_HEATMAP_INTENSITY,
    MAX_HEATMAP_INTENSITY
  );
  const routingEnabled = Boolean(stored?.routingEnabled ?? DEFAULT_ROUTING_ENABLED);
  const routingThreshold = clamp(
    Number(stored?.routingThreshold ?? DEFAULT_ROUTING_THRESHOLD),
    MIN_ROUTING_THRESHOLD,
    MAX_ROUTING_THRESHOLD
  );
  const routingShortCorner = String(
    stored?.routingShortCorner ?? DEFAULT_ROUTING_SHORT_CORNER
  );
  const routingLongCorner = String(
    stored?.routingLongCorner ?? DEFAULT_ROUTING_LONG_CORNER
  );
  const showLikesInNotifications = Boolean(
    stored?.showLikesInNotifications ?? DEFAULT_SHOW_LIKES_IN_NOTIFICATIONS
  );

  await chrome.storage.sync.set({
    active: isActive,
    position,
    overlayScale,
    displayDuration,
    overlayRadius,
    overlayAvatarSize,
    overlayGlassiness,
    overlayDarkness,
    debugMode,
    allowLongMessages,
    maxMessageChars,
    earlyModeEnabled,
    followPlaybackSpeed,
    earlySeconds,
    timestampAccentEffect,
    reverseStackOrder,
    popupDarkMode,
    priorityScoringEnabled,
    priorityLikesWeight,
    topLikedThresholdPercent,
    diamondThresholdPercent,
    heatmapEnabled,
    heatmapIntensity,
    routingEnabled,
    routingThreshold,
    routingShortCorner,
    routingLongCorner,
    showLikesInNotifications
  });

  return {
    isActive,
    position,
    overlayScale,
    displayDuration,
    overlayRadius,
    overlayAvatarSize,
    overlayGlassiness,
    overlayDarkness,
    debugMode,
    allowLongMessages,
    maxMessageChars,
    earlyModeEnabled,
    followPlaybackSpeed,
    earlySeconds,
    timestampAccentEffect,
    reverseStackOrder,
    popupDarkMode,
    priorityScoringEnabled,
    priorityLikesWeight,
    topLikedThresholdPercent,
    diamondThresholdPercent,
    heatmapEnabled,
    heatmapIntensity,
    routingEnabled,
    routingThreshold,
    routingShortCorner,
    routingLongCorner,
    showLikesInNotifications
  };
}

function updateSizeLabel(sizeSlider, sizeValue) {
  sizeValue.textContent = `${Math.round(Number(sizeSlider.value))}%`;
}

function updateDurationLabel(durationSlider, durationValue) {
  durationValue.textContent = `${Number(durationSlider.value).toFixed(1)}s`;
}

function updateRadiusLabel(radiusSlider, radiusValue) {
  radiusValue.textContent = `${Math.round(Number(radiusSlider.value))}px`;
}

function updateAvatarSizeLabel(avatarSizeSlider, avatarSizeValue) {
  avatarSizeValue.textContent = `${Math.round(Number(avatarSizeSlider.value))}px`;
}

function updateGlassLabel(glassSlider, glassValue) {
  glassValue.textContent = `${Math.round(Number(glassSlider.value))}%`;
}

function updateDarknessLabel(darknessSlider, darknessValue) {
  darknessValue.textContent = `${Math.round(Number(darknessSlider.value))}%`;
}

function updateHeatmapIntensityLabel(heatmapSlider, heatmapValue) {
  heatmapValue.textContent = `${Math.round(Number(heatmapSlider.value))}%`;
}

function updateTopLikedThresholdLabel(thresholdSlider, thresholdValue) {
  thresholdValue.textContent = `${Math.round(Number(thresholdSlider.value))}%`;
}

async function broadcastOverlaySettings({
  overlayScale,
  displayDuration,
  overlayRadius,
  overlayAvatarSize,
  overlayGlassiness,
  overlayDarkness,
  debugMode,
  allowLongMessages,
  maxMessageChars,
  earlyModeEnabled,
  followPlaybackSpeed,
  earlySeconds,
  timestampAccentEffect,
  reverseStackOrder,
  priorityScoringEnabled,
  priorityLikesWeight,
  topLikedThresholdPercent,
  diamondThresholdPercent,
  heatmapEnabled,
  heatmapIntensity,
  routingEnabled,
  routingThreshold,
  routingShortCorner,
  routingLongCorner,
  showLikesInNotifications
}) {
  await chrome.runtime.sendMessage({
    type: "overlaySettings",
    overlayScale,
    displayDuration,
    overlayRadius,
    overlayAvatarSize,
    overlayGlassiness,
    overlayDarkness,
    debugMode,
    allowLongMessages,
    maxMessageChars,
    earlyModeEnabled,
    followPlaybackSpeed,
    earlySeconds,
    timestampAccentEffect,
    reverseStackOrder,
    priorityScoringEnabled,
    priorityLikesWeight,
    topLikedThresholdPercent,
    diamondThresholdPercent,
    heatmapEnabled,
    heatmapIntensity,
    routingEnabled,
    routingThreshold,
    routingShortCorner,
    routingLongCorner,
    showLikesInNotifications
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  const configs = await getConfigs();
  const positionButtons = document.querySelectorAll(".position-button");
  const toggleButton = document.getElementById("togglebtn");

  const sizeSlider = document.getElementById("size-slider");
  const sizeValue = document.getElementById("size-value");
  const durationSlider = document.getElementById("duration-slider");
  const durationValue = document.getElementById("duration-value");
  const radiusSlider = document.getElementById("radius-slider");
  const radiusValue = document.getElementById("radius-value");
  const avatarSizeSlider = document.getElementById("avatar-size-slider");
  const avatarSizeValue = document.getElementById("avatar-size-value");
  const glassSlider = document.getElementById("glass-slider");
  const glassValue = document.getElementById("glass-value");
  const darknessSlider = document.getElementById("darkness-slider");
  const darknessValue = document.getElementById("darkness-value");
  const debugToggle = document.getElementById("debug-toggle");
  const allowLongToggle = document.getElementById("allow-long-toggle");
  const maxCharsInput = document.getElementById("max-chars-input");
  const earlyModeToggle = document.getElementById("early-mode-toggle");
  const followPlaybackSpeedToggle = document.getElementById("follow-playback-speed-toggle");
  const earlySecondsInput = document.getElementById("early-seconds-input");
  const accentEffectSelect = document.getElementById("accent-effect-select");
  const reverseStackToggle = document.getElementById("reverse-stack-toggle");
  const popupDarkToggle = document.getElementById("popup-dark-toggle");
  const priorityScoringToggle = document.getElementById("priority-scoring-toggle");
  const priorityLikesWeightInput = document.getElementById("priority-likes-weight-input");
  const topLikedThresholdSlider = document.getElementById("top-liked-threshold-slider");
  const topLikedThresholdValue = document.getElementById("top-liked-threshold-value");
  const heatmapEnabledToggle = document.getElementById("heatmap-enabled-toggle");
  const heatmapIntensitySlider = document.getElementById("heatmap-intensity-slider");
  const heatmapIntensityValue = document.getElementById("heatmap-intensity-value");
  const routingEnabledToggle = document.getElementById("routing-enabled-toggle");
  const routingThresholdInput = document.getElementById("routing-threshold-input");
  const routingShortCornerSelect = document.getElementById("routing-short-corner-select");
  const routingLongCornerSelect = document.getElementById("routing-long-corner-select");
  const showLikesToggle = document.getElementById("show-likes-toggle");
  const topLikedCutoffInline = document.getElementById("top-liked-cutoff-inline");
  const thresholdPreviewBadge = document.getElementById("threshold-preview-badge");
  let thresholdPreviewHideTimer = null;
  let thresholdPreviewRequestSeq = 0;

  if (configs.isActive === true) {
    toggleButton.classList.add("toggle_active");
  }

  sizeSlider.value = String(Math.round(configs.overlayScale * 100));
  durationSlider.value = String(configs.displayDuration);
  radiusSlider.value = String(configs.overlayRadius);
  avatarSizeSlider.value = String(configs.overlayAvatarSize);
  glassSlider.value = String(configs.overlayGlassiness);
  darknessSlider.value = String(configs.overlayDarkness);
  if (debugToggle) {
    debugToggle.checked = configs.debugMode;
  }
  allowLongToggle.checked = configs.allowLongMessages;
  maxCharsInput.value = String(configs.maxMessageChars);
  maxCharsInput.disabled = configs.allowLongMessages;
  earlyModeToggle.checked = configs.earlyModeEnabled;
  followPlaybackSpeedToggle.checked = configs.followPlaybackSpeed;
  earlySecondsInput.value = String(configs.earlySeconds);
  earlySecondsInput.disabled = !configs.earlyModeEnabled;
  accentEffectSelect.value = configs.timestampAccentEffect;
  accentEffectSelect.disabled = !configs.earlyModeEnabled;
  reverseStackToggle.checked = configs.reverseStackOrder;
  popupDarkToggle.checked = configs.popupDarkMode;
  priorityScoringToggle.checked = configs.priorityScoringEnabled;
  priorityLikesWeightInput.value = String(configs.priorityLikesWeight);
  topLikedThresholdSlider.value = String(configs.topLikedThresholdPercent);
  heatmapEnabledToggle.checked = configs.heatmapEnabled;
  heatmapIntensitySlider.value = String(configs.heatmapIntensity);
  routingEnabledToggle.checked = configs.routingEnabled;
  routingThresholdInput.value = String(configs.routingThreshold);
  routingShortCornerSelect.value = configs.routingShortCorner;
  routingLongCornerSelect.value = configs.routingLongCorner;
  showLikesToggle.checked = configs.showLikesInNotifications;
  priorityLikesWeightInput.disabled = !configs.priorityScoringEnabled;
  heatmapIntensitySlider.disabled = !configs.heatmapEnabled;
  routingThresholdInput.disabled = !configs.routingEnabled;
  routingShortCornerSelect.disabled = !configs.routingEnabled;
  routingLongCornerSelect.disabled = !configs.routingEnabled;
  document.body.classList.toggle("dark-mode", configs.popupDarkMode);

  updateSizeLabel(sizeSlider, sizeValue);
  updateDurationLabel(durationSlider, durationValue);
  updateRadiusLabel(radiusSlider, radiusValue);
  updateAvatarSizeLabel(avatarSizeSlider, avatarSizeValue);
  updateGlassLabel(glassSlider, glassValue);
  updateDarknessLabel(darknessSlider, darknessValue);
  updateHeatmapIntensityLabel(heatmapIntensitySlider, heatmapIntensityValue);
  updateTopLikedThresholdLabel(topLikedThresholdSlider, topLikedThresholdValue);
  showTopLikedCutoffPreview(Number(topLikedThresholdSlider.value));

  async function showTopLikedCutoffPreview(thresholdPercent) {
    if (topLikedCutoffInline) {
      topLikedCutoffInline.textContent = "Gold/Diamond cutoff: calculating...";
    }
    thresholdPreviewBadge.textContent = "Calculating gold cutoff...";
    thresholdPreviewBadge.classList.add("visible");
    if (thresholdPreviewHideTimer) {
      clearTimeout(thresholdPreviewHideTimer);
    }

    const videoId = await getActiveYouTubeVideoId();
    if (!videoId) {
      thresholdPreviewBadge.textContent = "Open a YouTube video to preview cutoff";
      if (topLikedCutoffInline) {
        topLikedCutoffInline.textContent = "Gold cutoff: open a YouTube video";
      }
      thresholdPreviewHideTimer = setTimeout(() => {
        thresholdPreviewBadge.classList.remove("visible");
      }, 1500);
      return;
    }

    const requestSeq = ++thresholdPreviewRequestSeq;
    const diamondPercent = deriveDiamondThresholdPercent(thresholdPercent);
    const [goldResponse, diamondResponse] = await Promise.all([
      chrome.runtime.sendMessage({
        type: "top_liked_cutoff_preview",
        videoId,
        thresholdPercent
      }),
      chrome.runtime.sendMessage({
        type: "top_liked_cutoff_preview",
        videoId,
        thresholdPercent: diamondPercent
      })
    ]);
    if (requestSeq !== thresholdPreviewRequestSeq) {
      return;
    }

    if (goldResponse?.ok) {
      const goldCutoff = Number(goldResponse.cutoffLikes || 0);
      const diamondCutoff = Number(diamondResponse?.cutoffLikes || 0);
      const goldText =
        goldCutoff > 0 ? `Gold cutoff: ${goldCutoff}+ likes` : "Gold cutoff: no liked comments found";
      thresholdPreviewBadge.textContent = goldText;
      if (topLikedCutoffInline) {
        const diamondText =
          diamondResponse?.ok && diamondCutoff > 0
            ? `Diamond cutoff: ${diamondCutoff}+ likes`
            : `Diamond cutoff: no liked comments found (top ${diamondPercent}%)`;
        topLikedCutoffInline.textContent = `${goldText} • ${diamondText}`;
      }
    } else {
      thresholdPreviewBadge.textContent = "Gold cutoff preview unavailable";
      if (topLikedCutoffInline) {
        topLikedCutoffInline.textContent = "Gold/Diamond cutoff: preview unavailable";
      }
    }
    if (thresholdPreviewHideTimer) {
      clearTimeout(thresholdPreviewHideTimer);
    }
    thresholdPreviewHideTimer = setTimeout(() => {
      thresholdPreviewBadge.classList.remove("visible");
    }, 1500);
  }

  toggleButton.addEventListener("click", async () => {
    const wasActive = toggleButton.classList.contains("toggle_active");
    const currentState = !wasActive;
    toggleButton.classList.toggle("toggle_active", currentState);
    await chrome.storage.sync.set({ active: currentState });
    await chrome.runtime.sendMessage({ type: "isActive", status: currentState });
  });

  positionButtons.forEach((button) => {
    if (button.dataset.position === configs.position) {
      button.classList.add("selected");
    }

    button.addEventListener("click", async (event) => {
      const target = event.currentTarget;
      const newPosition = target.dataset.position;
      if (lastPosition === newPosition) {
        return;
      }

      const selected = target.parentElement.querySelector(".selected");
      if (selected) {
        selected.classList.remove("selected");
      }
      target.classList.add("selected");
      await chrome.runtime.sendMessage({ type: "position", position: newPosition });
      lastPosition = newPosition;
    });
  });

  sizeSlider.addEventListener("input", () => updateSizeLabel(sizeSlider, sizeValue));
  durationSlider.addEventListener("input", () =>
    updateDurationLabel(durationSlider, durationValue)
  );
  radiusSlider.addEventListener("input", () => updateRadiusLabel(radiusSlider, radiusValue));
  avatarSizeSlider.addEventListener("input", () =>
    updateAvatarSizeLabel(avatarSizeSlider, avatarSizeValue)
  );
  glassSlider.addEventListener("input", () => updateGlassLabel(glassSlider, glassValue));
  darknessSlider.addEventListener("input", () =>
    updateDarknessLabel(darknessSlider, darknessValue)
  );
  heatmapIntensitySlider.addEventListener("input", () =>
    updateHeatmapIntensityLabel(heatmapIntensitySlider, heatmapIntensityValue)
  );
  topLikedThresholdSlider.addEventListener("input", () =>
    {
      updateTopLikedThresholdLabel(topLikedThresholdSlider, topLikedThresholdValue);
      showTopLikedCutoffPreview(Number(topLikedThresholdSlider.value));
    }
  );

  async function saveOverlaySettings() {
    const overlayScale = clamp(
      Number(sizeSlider.value) / 100,
      MIN_OVERLAY_SCALE,
      MAX_OVERLAY_SCALE
    );
    const displayDuration = clamp(
      Number(durationSlider.value),
      MIN_DISPLAY_DURATION,
      MAX_DISPLAY_DURATION
    );
    const overlayRadius = clamp(
      Number(radiusSlider.value),
      MIN_OVERLAY_RADIUS,
      MAX_OVERLAY_RADIUS
    );
    const overlayAvatarSize = clamp(
      Number(avatarSizeSlider.value),
      MIN_OVERLAY_AVATAR_SIZE,
      MAX_OVERLAY_AVATAR_SIZE
    );
    const overlayGlassiness = clamp(
      Number(glassSlider.value),
      MIN_OVERLAY_GLASSINESS,
      MAX_OVERLAY_GLASSINESS
    );
    const overlayDarkness = clamp(
      Number(darknessSlider.value),
      MIN_OVERLAY_DARKNESS,
      MAX_OVERLAY_DARKNESS
    );
    const debugMode = debugToggle ? Boolean(debugToggle.checked) : configs.debugMode;
    const allowLongMessages = Boolean(allowLongToggle.checked);
    const maxMessageChars = clamp(
      Number(maxCharsInput.value || DEFAULT_MAX_MESSAGE_CHARS),
      MIN_MAX_MESSAGE_CHARS,
      MAX_MAX_MESSAGE_CHARS
    );
    maxCharsInput.value = String(maxMessageChars);
    maxCharsInput.disabled = allowLongMessages;
    const earlyModeEnabled = Boolean(earlyModeToggle.checked);
    const followPlaybackSpeed = Boolean(followPlaybackSpeedToggle.checked);
    const earlySeconds = clamp(
      Number(earlySecondsInput.value || DEFAULT_EARLY_SECONDS),
      MIN_EARLY_SECONDS,
      MAX_EARLY_SECONDS
    );
    const timestampAccentEffect = String(
      accentEffectSelect.value || DEFAULT_TIMESTAMP_ACCENT_EFFECT
    );
    const reverseStackOrder = Boolean(reverseStackToggle.checked);
    const priorityScoringEnabled = Boolean(priorityScoringToggle.checked);
    const priorityLikesWeight = clamp(
      Number(priorityLikesWeightInput.value || DEFAULT_PRIORITY_LIKES_WEIGHT),
      MIN_PRIORITY_LIKES_WEIGHT,
      MAX_PRIORITY_LIKES_WEIGHT
    );
    const topLikedThresholdPercent = clamp(
      Number(topLikedThresholdSlider.value || DEFAULT_TOP_LIKED_THRESHOLD_PERCENT),
      MIN_TOP_LIKED_THRESHOLD_PERCENT,
      MAX_TOP_LIKED_THRESHOLD_PERCENT
    );
    const diamondThresholdPercent = deriveDiamondThresholdPercent(topLikedThresholdPercent);
    const heatmapEnabled = Boolean(heatmapEnabledToggle.checked);
    const heatmapIntensity = clamp(
      Number(heatmapIntensitySlider.value || DEFAULT_HEATMAP_INTENSITY),
      MIN_HEATMAP_INTENSITY,
      MAX_HEATMAP_INTENSITY
    );
    const routingEnabled = Boolean(routingEnabledToggle.checked);
    const routingThreshold = clamp(
      Number(routingThresholdInput.value || DEFAULT_ROUTING_THRESHOLD),
      MIN_ROUTING_THRESHOLD,
      MAX_ROUTING_THRESHOLD
    );
    const routingShortCorner = String(
      routingShortCornerSelect.value || DEFAULT_ROUTING_SHORT_CORNER
    );
    const routingLongCorner = String(
      routingLongCornerSelect.value || DEFAULT_ROUTING_LONG_CORNER
    );
    const showLikesInNotifications = Boolean(showLikesToggle.checked);
    earlySecondsInput.value = String(earlySeconds);
    priorityLikesWeightInput.value = String(priorityLikesWeight);
    topLikedThresholdSlider.value = String(topLikedThresholdPercent);
    heatmapIntensitySlider.value = String(heatmapIntensity);
    routingThresholdInput.value = String(routingThreshold);
    earlySecondsInput.disabled = !earlyModeEnabled;
    accentEffectSelect.disabled = !earlyModeEnabled;
    priorityLikesWeightInput.disabled = !priorityScoringEnabled;
    heatmapIntensitySlider.disabled = !heatmapEnabled;
    routingThresholdInput.disabled = !routingEnabled;
    routingShortCornerSelect.disabled = !routingEnabled;
    routingLongCornerSelect.disabled = !routingEnabled;

    const settings = {
      overlayScale,
      displayDuration,
      overlayRadius,
      overlayAvatarSize,
      overlayGlassiness,
      overlayDarkness,
      debugMode,
      allowLongMessages,
      maxMessageChars,
      earlyModeEnabled,
      followPlaybackSpeed,
      earlySeconds,
      timestampAccentEffect,
      reverseStackOrder,
      priorityScoringEnabled,
      priorityLikesWeight,
      topLikedThresholdPercent,
      diamondThresholdPercent,
      heatmapEnabled,
      heatmapIntensity,
      routingEnabled,
      routingThreshold,
      routingShortCorner,
      routingLongCorner,
      showLikesInNotifications
    };

    await chrome.storage.sync.set(settings);
    await broadcastOverlaySettings(settings);
  }

  sizeSlider.addEventListener("change", saveOverlaySettings);
  durationSlider.addEventListener("change", saveOverlaySettings);
  radiusSlider.addEventListener("change", saveOverlaySettings);
  avatarSizeSlider.addEventListener("change", saveOverlaySettings);
  glassSlider.addEventListener("change", saveOverlaySettings);
  darknessSlider.addEventListener("change", saveOverlaySettings);
  if (debugToggle) {
    debugToggle.addEventListener("change", saveOverlaySettings);
  }
  allowLongToggle.addEventListener("change", saveOverlaySettings);
  maxCharsInput.addEventListener("change", saveOverlaySettings);
  earlyModeToggle.addEventListener("change", saveOverlaySettings);
  followPlaybackSpeedToggle.addEventListener("change", saveOverlaySettings);
  earlySecondsInput.addEventListener("change", saveOverlaySettings);
  accentEffectSelect.addEventListener("change", saveOverlaySettings);
  reverseStackToggle.addEventListener("change", saveOverlaySettings);
  priorityScoringToggle.addEventListener("change", saveOverlaySettings);
  priorityLikesWeightInput.addEventListener("change", saveOverlaySettings);
  topLikedThresholdSlider.addEventListener("change", saveOverlaySettings);
  heatmapEnabledToggle.addEventListener("change", saveOverlaySettings);
  heatmapIntensitySlider.addEventListener("change", saveOverlaySettings);
  routingEnabledToggle.addEventListener("change", saveOverlaySettings);
  routingThresholdInput.addEventListener("change", saveOverlaySettings);
  routingShortCornerSelect.addEventListener("change", saveOverlaySettings);
  routingLongCornerSelect.addEventListener("change", saveOverlaySettings);
  showLikesToggle.addEventListener("change", saveOverlaySettings);
  popupDarkToggle.addEventListener("change", async () => {
    const popupDarkMode = Boolean(popupDarkToggle.checked);
    document.body.classList.toggle("dark-mode", popupDarkMode);
    await chrome.storage.sync.set({ popupDarkMode });
  });

});
