let overlayElement = null;
let markerBarElement = null;
let markerPreviewElement = null;
let position = "bottom-left";
let videoContainer = null;
let isActive = true;
let monitoringInitialized = false;
let comments = [];
let activeCards = [];
let activeCardByCommentId = new Map();
let currentVideoId = null;
let laneElements = new Map();
let topLikedThreshold = 0;
let diamondLikedThreshold = Number.POSITIVE_INFINITY;
let eyeToggleElement = null;
let notificationsMutedByEye = false;
let isVideoHovering = false;
let reconcileRafId = null;
let pendingReconcileTime = null;
let renderMarkersRafId = null;

const DEFAULT_OVERLAY_SCALE = 1.05;
const DEFAULT_DISPLAY_DURATION = 14;
const DEFAULT_OVERLAY_RADIUS = 14;
const DEFAULT_OVERLAY_AVATAR_SIZE = 25;
const DEFAULT_OVERLAY_GLASSINESS = 24;
const DEFAULT_OVERLAY_DARKNESS = 31;
const DEFAULT_DEBUG_MODE = false;
const DEFAULT_EARLY_MODE_ENABLED = false;
const DEFAULT_FOLLOW_PLAYBACK_SPEED = true;
const DEFAULT_EARLY_SECONDS = 5;
const DEFAULT_TIMESTAMP_ACCENT_EFFECT = "rubberband";
const DEFAULT_REVERSE_STACK_ORDER = false;
const DEFAULT_PRIORITY_SCORING_ENABLED = true;
const DEFAULT_PRIORITY_LIKES_WEIGHT = 1;
const DEFAULT_TOP_LIKED_THRESHOLD_PERCENT = 12;
const DEFAULT_HEATMAP_ENABLED = true;
const DEFAULT_HEATMAP_INTENSITY = 500;
const DEFAULT_ROUTING_ENABLED = false;
const DEFAULT_ROUTING_THRESHOLD = 80;
const DEFAULT_ROUTING_SHORT_CORNER = "bottom-left";
const DEFAULT_ROUTING_LONG_CORNER = "top-right";
const DEFAULT_SHOW_LIKES_IN_NOTIFICATIONS = true;

let overlayScale = DEFAULT_OVERLAY_SCALE;
let displayDuration = DEFAULT_DISPLAY_DURATION;
let overlayRadius = DEFAULT_OVERLAY_RADIUS;
let overlayAvatarSize = DEFAULT_OVERLAY_AVATAR_SIZE;
let overlayGlassiness = DEFAULT_OVERLAY_GLASSINESS;
let overlayDarkness = DEFAULT_OVERLAY_DARKNESS;
let debugMode = DEFAULT_DEBUG_MODE;
let earlyModeEnabled = DEFAULT_EARLY_MODE_ENABLED;
let followPlaybackSpeed = DEFAULT_FOLLOW_PLAYBACK_SPEED;
let earlySeconds = DEFAULT_EARLY_SECONDS;
let timestampAccentEffect = DEFAULT_TIMESTAMP_ACCENT_EFFECT;
let reverseStackOrder = DEFAULT_REVERSE_STACK_ORDER;
let priorityScoringEnabled = DEFAULT_PRIORITY_SCORING_ENABLED;
let priorityLikesWeight = DEFAULT_PRIORITY_LIKES_WEIGHT;
let topLikedThresholdPercent = DEFAULT_TOP_LIKED_THRESHOLD_PERCENT;
let heatmapEnabled = DEFAULT_HEATMAP_ENABLED;
let heatmapIntensity = DEFAULT_HEATMAP_INTENSITY;
let routingEnabled = DEFAULT_ROUTING_ENABLED;
let routingThreshold = DEFAULT_ROUTING_THRESHOLD;
let routingShortCorner = DEFAULT_ROUTING_SHORT_CORNER;
let routingLongCorner = DEFAULT_ROUTING_LONG_CORNER;
let showLikesInNotifications = DEFAULT_SHOW_LIKES_IN_NOTIFICATIONS;

const MIN_OVERLAY_SCALE = 0.5;
const MAX_OVERLAY_SCALE = 3.5;
const MIN_DISPLAY_DURATION = 1;
const MAX_DISPLAY_DURATION = 60;
const MIN_OVERLAY_RADIUS = 0;
const MAX_OVERLAY_RADIUS = 120;
const MIN_OVERLAY_AVATAR_SIZE = 20;
const MAX_OVERLAY_AVATAR_SIZE = 84;
const MIN_OVERLAY_GLASSINESS = 0;
const MAX_OVERLAY_GLASSINESS = 100;
const MIN_OVERLAY_DARKNESS = 0;
const MAX_OVERLAY_DARKNESS = 100;
const MIN_EARLY_SECONDS = 0;
const MAX_EARLY_SECONDS = 60;
const MIN_PRIORITY_LIKES_WEIGHT = 0;
const MAX_PRIORITY_LIKES_WEIGHT = 5;
const MIN_TOP_LIKED_THRESHOLD_PERCENT = 1;
const MAX_TOP_LIKED_THRESHOLD_PERCENT = 50;
const MIN_HEATMAP_INTENSITY = 10;
const MAX_HEATMAP_INTENSITY = 2000;
const MIN_ROUTING_THRESHOLD = 1;
const MAX_ROUTING_THRESHOLD = 5000;
const CORNERS = ["bottom-left", "bottom-right", "top-left", "top-right"];

const timestampRegex = /(\d{1,}):([0-5]\d)(?::([0-5]\d))?/;
let upcomingDotElement = null;

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function debugLog(...args) {
  if (debugMode) {
    console.log("[KonsYTimestamps]", ...args);
  }
}

function scheduleReconcile(currentTime) {
  pendingReconcileTime = Number(currentTime);
  if (reconcileRafId !== null) {
    return;
  }
  reconcileRafId = requestAnimationFrame(() => {
    reconcileRafId = null;
    const nextTime = pendingReconcileTime;
    pendingReconcileTime = null;
    if (!Number.isFinite(nextTime)) {
      return;
    }
    reconcileVisibleComments(nextTime);
  });
}

function scheduleRenderTimeMarkers() {
  if (renderMarkersRafId !== null) {
    return;
  }
  renderMarkersRafId = requestAnimationFrame(() => {
    renderMarkersRafId = null;
    renderTimeMarkers();
  });
}

function getActivePlaybackRate() {
  const playbackRate = Number(getVideo()?.playbackRate || 1);
  return Number.isFinite(playbackRate) && playbackRate > 0 ? playbackRate : 1;
}

function getBaseDisplayDurationSeconds() {
  return Math.max(MIN_DISPLAY_DURATION, displayDuration - 1);
}

function getCommentDisplayDurationSeconds(comment, playbackRate = 1) {
  const baseSeconds = getBaseDisplayDurationSeconds();
  const likesCount = Number(comment?.likes || 0);
  const tierRank = getTierRank(likesCount);
  const tierDurationSeconds = tierRank >= 2 ? baseSeconds * 1.3 : tierRank >= 1 ? baseSeconds * 1.2 : baseSeconds;
  if (followPlaybackSpeed) {
    return tierDurationSeconds;
  }
  return tierDurationSeconds * playbackRate;
}

function getDisplayDurationMs(comment = null, playbackRate = 1) {
  return Math.round(getCommentDisplayDurationSeconds(comment, playbackRate) * 1000);
}

function getEyeIconSvg(closed) {
  if (closed) {
    return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M4 12s3-5 8-5c1.5 0 2.8.4 4 1.1M20 12s-1.1 1.9-3 3.4M14.2 14.2a3 3 0 0 1-4.2-4.2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
  }
  return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12S6.5 6 12 6s9.5 6 9.5 6-4 6-9.5 6S2.5 12 2.5 12z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="12" r="2.8" fill="currentColor"/></svg>';
}

function isPlayerHoverActive() {
  const host = getOverlayHost() || videoContainer;
  if (!host) {
    return isVideoHovering;
  }
  if (host.classList.contains("ytp-autohide")) {
    return false;
  }
  return isVideoHovering;
}

function shouldShowEyeToggle() {
  return isActive;
}

function ensureEyeToggle() {
  if (!overlayElement) {
    return null;
  }
  if (eyeToggleElement && eyeToggleElement.isConnected) {
    return eyeToggleElement;
  }
  const existing = overlayElement.querySelector(".overlay-eye-toggle");
  if (existing) {
    eyeToggleElement = existing;
    return eyeToggleElement;
  }

  eyeToggleElement = document.createElement("button");
  eyeToggleElement.className = "overlay-eye-toggle";
  eyeToggleElement.type = "button";
  eyeToggleElement.innerHTML = getEyeIconSvg(notificationsMutedByEye);
  eyeToggleElement.classList.toggle("muted", notificationsMutedByEye);
  eyeToggleElement.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    notificationsMutedByEye = !notificationsMutedByEye;
    eyeToggleElement.classList.toggle("muted", notificationsMutedByEye);
    eyeToggleElement.innerHTML = getEyeIconSvg(notificationsMutedByEye);
    if (notificationsMutedByEye) {
      hideOverlay();
      setUpcomingDotVisible(false);
      updateEyeToggleVisibility();
      return;
    }
    const video = getVideo();
    if (video) {
      scheduleReconcile(video.currentTime);
    }
  });
  overlayElement.appendChild(eyeToggleElement);
  return eyeToggleElement;
}

function updateEyeToggleVisibility() {
  if (!overlayElement) {
    return;
  }
  if (!shouldShowEyeToggle()) {
    if (eyeToggleElement) {
      eyeToggleElement.classList.remove("visible");
    }
    return;
  }
  if (!ensureOverlayAttached()) {
    return;
  }
  const eye = ensureEyeToggle();
  if (eye) {
    eye.classList.add("visible");
    eye.classList.toggle("muted", notificationsMutedByEye);
    eye.innerHTML = getEyeIconSvg(notificationsMutedByEye);
  }
}

function attachHoverTracking(host) {
  if (!host || host.dataset.konsHoverBound === "1") {
    return;
  }
  host.dataset.konsHoverBound = "1";
  host.addEventListener("mouseenter", () => {
    isVideoHovering = true;
    updateEyeToggleVisibility();
    setUpcomingDotVisible(false);
  });
  host.addEventListener("mouseleave", () => {
    isVideoHovering = false;
    updateEyeToggleVisibility();
  });
}

function getCommentKey(comment) {
  if (comment?.id !== undefined && comment?.id !== null) {
    return String(comment.id);
  }
  return `${comment.time}:${comment.name}:${comment.text}`;
}

function normalizeCorner(value, fallback) {
  return CORNERS.includes(value) ? value : fallback;
}

function getPriorityScore(comment) {
  if (!priorityScoringEnabled) {
    return 0;
  }
  const likes = Number(comment?.likes || 0);
  return likes * priorityLikesWeight;
}

function computeTopLikedThreshold(sourceComments) {
  const likeBySource = new Map();
  (sourceComments || []).forEach((comment) => {
    const sourceKey = comment?.sourceId || comment?.id;
    const likes = Number(comment?.likes || 0);
    if (!sourceKey || !Number.isFinite(likes) || likes <= 0) {
      return;
    }
    const previous = likeBySource.get(sourceKey) || 0;
    if (likes > previous) {
      likeBySource.set(sourceKey, likes);
    }
  });

  const likes = [...likeBySource.values()]
    .sort((a, b) => b - a);
  if (likes.length === 0) {
    return 0;
  }
  const ratio =
    clamp(
      topLikedThresholdPercent,
      MIN_TOP_LIKED_THRESHOLD_PERCENT,
      MAX_TOP_LIKED_THRESHOLD_PERCENT
    ) / 100;
  const topPoolSize = Math.max(1, Math.ceil(likes.length * ratio));
  return likes[topPoolSize - 1];
}

function deriveDiamondThresholdPercent() {
  return Math.max(1, Math.floor(topLikedThresholdPercent * 0.35));
}

function computeDiamondLikedThreshold(sourceComments) {
  const likeBySource = new Map();
  (sourceComments || []).forEach((comment) => {
    const sourceKey = comment?.sourceId || comment?.id;
    const likes = Number(comment?.likes || 0);
    if (!sourceKey || !Number.isFinite(likes) || likes <= 0) {
      return;
    }
    const previous = likeBySource.get(sourceKey) || 0;
    if (likes > previous) {
      likeBySource.set(sourceKey, likes);
    }
  });

  const likes = [...likeBySource.values()]
    .sort((a, b) => b - a);
  if (likes.length === 0) {
    return Number.POSITIVE_INFINITY;
  }
  const ratio =
    deriveDiamondThresholdPercent() / 100;
  const poolSize = Math.max(1, Math.ceil(likes.length * ratio));
  return likes[poolSize - 1];
}

function recomputeLikeTierThresholds() {
  topLikedThreshold = computeTopLikedThreshold(comments);
  diamondLikedThreshold = computeDiamondLikedThreshold(comments);
}

function compareByPriority(a, b) {
  const scoreDiff = getPriorityScore(b) - getPriorityScore(a);
  if (scoreDiff !== 0) {
    return scoreDiff;
  }
  return String(a.id || "").localeCompare(String(b.id || ""));
}

function resolveCommentCorner(comment) {
  if (!routingEnabled) {
    return position;
  }
  if ((comment?.text || "").length <= routingThreshold) {
    return routingShortCorner;
  }
  return routingLongCorner;
}

function getTierRank(likesCount) {
  if (likesCount > 0 && likesCount >= diamondLikedThreshold) {
    return 2;
  }
  if (likesCount > 0 && likesCount >= topLikedThreshold) {
    return 1;
  }
  return 0;
}

function getTierOrderForCorner(corner, tierRank) {
  const isTopCorner = corner === "top-left" || corner === "top-right";
  return isTopCorner ? -tierRank : tierRank;
}

function formatLikesLabel(likesCount) {
  const value = Number(likesCount || 0);
  if (!Number.isFinite(value) || value <= 0) {
    return "0";
  }
  if (value >= 1_000_000_000) {
    const compact = (value / 1_000_000_000).toFixed(1).replace(/\.0$/, "");
    return `${compact}B`;
  }
  if (value >= 1_000_000) {
    const compact = (value / 1_000_000).toFixed(1).replace(/\.0$/, "");
    return `${compact}M`;
  }
  if (value >= 1_000) {
    const compact = (value / 1_000).toFixed(1).replace(/\.0$/, "");
    return `${compact}K`;
  }
  return String(Math.round(value));
}

function ensureLaneContainers() {
  if (!overlayElement) {
    return;
  }
  for (const corner of CORNERS) {
    if (laneElements.has(corner) && laneElements.get(corner).isConnected) {
      continue;
    }
    const existing = overlayElement.querySelector(`.overlay-lane.${corner}`);
    if (existing) {
      laneElements.set(corner, existing);
      continue;
    }
    const lane = document.createElement("div");
    lane.className = `overlay-lane ${corner}`;
    overlayElement.appendChild(lane);
    laneElements.set(corner, lane);
  }
}

function getLaneElement(corner) {
  ensureLaneContainers();
  return laneElements.get(corner) || null;
}

function updateLaneVisibility() {
  if (!overlayElement) {
    return;
  }
  ensureLaneContainers();
  for (const corner of CORNERS) {
    const lane = laneElements.get(corner);
    if (!lane) {
      continue;
    }
    const visible = routingEnabled || corner === position;
    lane.classList.toggle("hidden", !visible);
  }
  updateEyeToggleVisibility();
}

function seekToCommentContext(comment, contextSeconds = 2) {
  const video = getVideo();
  const currentTime = Number(video?.currentTime || 0);
  const candidates =
    Array.isArray(comment?.timestamps) && comment.timestamps.length > 0
      ? comment.timestamps.map((value) => Number(value)).filter((value) => Number.isFinite(value))
      : [Number(comment?.time || 0)];
  const closestTimestamp = candidates.reduce((closest, candidate) => {
    return Math.abs(candidate - currentTime) < Math.abs(closest - currentTime)
      ? candidate
      : closest;
  }, candidates[0] || 0);
  const targetTime = Math.max(0, Number(closestTimestamp || 0) - contextSeconds);

  if (video) {
    video.currentTime = targetTime;
    return;
  }

  const videoId = currentVideoId || getVideoId();
  if (!videoId) {
    return;
  }
  const time = Math.floor(targetTime);
  const lcKey = comment?.sourceId || comment?.id;
  const lcPart = lcKey ? `&lc=${encodeURIComponent(lcKey)}` : "";
  const url = `https://www.youtube.com/watch?v=${videoId}${lcPart}&t=${time}s`;
  window.location.href = url;
}

function ensureUpcomingDot() {
  if (!overlayElement) {
    return null;
  }
  const lane = getLaneElement("bottom-left");
  if (!lane) {
    return null;
  }
  if (upcomingDotElement && upcomingDotElement.isConnected) {
    return upcomingDotElement;
  }
  const existing = lane.querySelector(".overlay-upcoming-dot");
  if (existing) {
    upcomingDotElement = existing;
    return upcomingDotElement;
  }
  upcomingDotElement = document.createElement("div");
  upcomingDotElement.className = "overlay-upcoming-dot";
  lane.appendChild(upcomingDotElement);
  return upcomingDotElement;
}

function setUpcomingDotVisible(visible) {
  if (!overlayElement) {
    return;
  }
  if (
    !visible ||
    !isActive ||
    notificationsMutedByEye ||
    shouldShowEyeToggle() ||
    position !== "bottom-left" ||
    routingEnabled
  ) {
    if (upcomingDotElement) {
      upcomingDotElement.classList.remove("visible");
    }
    return;
  }
  if (!ensureOverlayAttached()) {
    return;
  }
  const dot = ensureUpcomingDot();
  if (dot) {
    dot.classList.add("visible");
  }
}

function formatTime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) {
    return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${m}:${String(s).padStart(2, "0")}`;
}

function locationChange(callback) {
  let currentUrl = location.href;
  const observer = new MutationObserver(() => {
    if (currentUrl !== document.location.href) {
      currentUrl = document.location.href;
      callback();
    }
  });
  observer.observe(document.querySelector("body"), { childList: true, subtree: true });
}

function applyOverlayStyles() {
  if (!overlayElement) {
    return;
  }

  const glassNormalized =
    clamp(overlayGlassiness, MIN_OVERLAY_GLASSINESS, MAX_OVERLAY_GLASSINESS) / 100;
  const darknessNormalized =
    clamp(overlayDarkness, MIN_OVERLAY_DARKNESS, MAX_OVERLAY_DARKNESS) / 100;

  const blurPx = (2 + glassNormalized * 22).toFixed(1);
  const glassTintAlpha = (0.04 + glassNormalized * 0.24).toFixed(3);
  const glassRimAlpha = (0.12 + glassNormalized * 0.5).toFixed(3);
  const glassSheenAlpha = (0.06 + glassNormalized * 0.34).toFixed(3);
  const bgAlpha = (0.18 + darknessNormalized * 0.72).toFixed(3);
  const borderAlpha = (0.1 + darknessNormalized * 0.36).toFixed(3);
  const shadowAlpha = (0.18 + darknessNormalized * 0.47).toFixed(3);
  const warningAlpha = (0.52 + darknessNormalized * 0.42).toFixed(3);
  const warningBorderAlpha = (0.34 + darknessNormalized * 0.44).toFixed(3);
  const warningGlowAlpha = (0.55 + darknessNormalized * 0.4).toFixed(3);
  const heatmapIntensityRatio =
    clamp(heatmapIntensity, MIN_HEATMAP_INTENSITY, MAX_HEATMAP_INTENSITY) /
    MAX_HEATMAP_INTENSITY;
  const heatmapAlpha = clamp(
    0.2 + Math.pow(heatmapIntensityRatio, 0.65) * 0.75,
    0.2,
    0.95
  ).toFixed(3);

  overlayElement.style.setProperty("--overlay-scale", String(overlayScale));
  overlayElement.style.setProperty("--overlay-radius", `${overlayRadius}px`);
  overlayElement.style.setProperty("--overlay-avatar-size", `${overlayAvatarSize}px`);
  overlayElement.style.setProperty("--overlay-bg-alpha", bgAlpha);
  overlayElement.style.setProperty("--overlay-blur", `${blurPx}px`);
  overlayElement.style.setProperty("--overlay-glass-tint-alpha", glassTintAlpha);
  overlayElement.style.setProperty("--overlay-glass-rim-alpha", glassRimAlpha);
  overlayElement.style.setProperty("--overlay-glass-sheen-alpha", glassSheenAlpha);
  overlayElement.style.setProperty("--overlay-border-alpha", borderAlpha);
  overlayElement.style.setProperty("--overlay-shadow-alpha", shadowAlpha);
  overlayElement.style.setProperty("--overlay-warning-alpha", warningAlpha);
  overlayElement.style.setProperty("--overlay-warning-border-alpha", warningBorderAlpha);
  overlayElement.style.setProperty("--overlay-warning-glow-alpha", warningGlowAlpha);
  overlayElement.style.setProperty("--overlay-heatmap-alpha", heatmapAlpha);
  overlayElement.classList.toggle("debug-mode", debugMode);
  updateLaneVisibility();
}

async function getOverlaySettings() {
  const values = await chrome.storage.sync.get([
    "overlayScale",
    "displayDuration",
    "overlayRadius",
    "overlayAvatarSize",
    "overlayGlassiness",
    "overlayDarkness",
    "debugMode",
    "earlyModeEnabled",
    "followPlaybackSpeed",
    "earlySeconds",
    "timestampAccentEffect",
    "reverseStackOrder",
    "priorityScoringEnabled",
    "priorityLikesWeight",
    "topLikedThresholdPercent",
    "heatmapEnabled",
    "heatmapIntensity",
    "routingEnabled",
    "routingThreshold",
    "routingShortCorner",
    "routingLongCorner",
    "showLikesInNotifications"
  ]);

  overlayScale = clamp(Number(values?.overlayScale ?? DEFAULT_OVERLAY_SCALE), MIN_OVERLAY_SCALE, MAX_OVERLAY_SCALE);
  displayDuration = clamp(
    Number(values?.displayDuration ?? DEFAULT_DISPLAY_DURATION),
    MIN_DISPLAY_DURATION,
    MAX_DISPLAY_DURATION
  );
  overlayRadius = clamp(
    Number(values?.overlayRadius ?? DEFAULT_OVERLAY_RADIUS),
    MIN_OVERLAY_RADIUS,
    MAX_OVERLAY_RADIUS
  );
  overlayAvatarSize = clamp(
    Number(values?.overlayAvatarSize ?? DEFAULT_OVERLAY_AVATAR_SIZE),
    MIN_OVERLAY_AVATAR_SIZE,
    MAX_OVERLAY_AVATAR_SIZE
  );
  overlayGlassiness = clamp(
    Number(values?.overlayGlassiness ?? DEFAULT_OVERLAY_GLASSINESS),
    MIN_OVERLAY_GLASSINESS,
    MAX_OVERLAY_GLASSINESS
  );
  overlayDarkness = clamp(
    Number(values?.overlayDarkness ?? DEFAULT_OVERLAY_DARKNESS),
    MIN_OVERLAY_DARKNESS,
    MAX_OVERLAY_DARKNESS
  );
  debugMode = Boolean(values?.debugMode ?? DEFAULT_DEBUG_MODE);
  earlyModeEnabled = Boolean(values?.earlyModeEnabled ?? DEFAULT_EARLY_MODE_ENABLED);
  followPlaybackSpeed = Boolean(values?.followPlaybackSpeed ?? DEFAULT_FOLLOW_PLAYBACK_SPEED);
  earlySeconds = clamp(
    Number(values?.earlySeconds ?? DEFAULT_EARLY_SECONDS),
    MIN_EARLY_SECONDS,
    MAX_EARLY_SECONDS
  );
  timestampAccentEffect = String(
    values?.timestampAccentEffect ?? DEFAULT_TIMESTAMP_ACCENT_EFFECT
  );
  reverseStackOrder = Boolean(values?.reverseStackOrder ?? DEFAULT_REVERSE_STACK_ORDER);
  priorityScoringEnabled = Boolean(
    values?.priorityScoringEnabled ?? DEFAULT_PRIORITY_SCORING_ENABLED
  );
  priorityLikesWeight = clamp(
    Number(values?.priorityLikesWeight ?? DEFAULT_PRIORITY_LIKES_WEIGHT),
    MIN_PRIORITY_LIKES_WEIGHT,
    MAX_PRIORITY_LIKES_WEIGHT
  );
  topLikedThresholdPercent = clamp(
    Number(values?.topLikedThresholdPercent ?? DEFAULT_TOP_LIKED_THRESHOLD_PERCENT),
    MIN_TOP_LIKED_THRESHOLD_PERCENT,
    MAX_TOP_LIKED_THRESHOLD_PERCENT
  );
  heatmapEnabled = Boolean(values?.heatmapEnabled ?? DEFAULT_HEATMAP_ENABLED);
  heatmapIntensity = clamp(
    Number(values?.heatmapIntensity ?? DEFAULT_HEATMAP_INTENSITY),
    MIN_HEATMAP_INTENSITY,
    MAX_HEATMAP_INTENSITY
  );
  routingEnabled = Boolean(values?.routingEnabled ?? DEFAULT_ROUTING_ENABLED);
  routingThreshold = clamp(
    Number(values?.routingThreshold ?? DEFAULT_ROUTING_THRESHOLD),
    MIN_ROUTING_THRESHOLD,
    MAX_ROUTING_THRESHOLD
  );
  routingShortCorner = normalizeCorner(
    String(values?.routingShortCorner ?? DEFAULT_ROUTING_SHORT_CORNER),
    DEFAULT_ROUTING_SHORT_CORNER
  );
  routingLongCorner = normalizeCorner(
    String(values?.routingLongCorner ?? DEFAULT_ROUTING_LONG_CORNER),
    DEFAULT_ROUTING_LONG_CORNER
  );
  showLikesInNotifications = Boolean(
    values?.showLikesInNotifications ?? DEFAULT_SHOW_LIKES_IN_NOTIFICATIONS
  );
}

async function main() {
  resetVariables();
  isActive = await isActiveFunc();
  position = await getCommentPosition();
  await getOverlaySettings();

  const videoId = getVideoId();
  currentVideoId = videoId;
  if (videoId) {
    await chrome.runtime.sendMessage({ type: "comments", video_id: videoId });
    createInterface();
    scheduleRenderTimeMarkers();
  }
}

function getVideoId() {
  if (window.location.pathname === "/watch") {
    return new URL(location.href).searchParams.get("v");
  }
  if (window.location.pathname.startsWith("/embed/")) {
    return window.location.pathname.substring("/embed/".length);
  }
  return null;
}

function getVideo() {
  return document.querySelector("#movie_player video") || document.querySelector("video");
}

function getOverlayHost() {
  const moviePlayer = document.querySelector("#movie_player");
  if (moviePlayer) {
    return moviePlayer;
  }

  const html5Player =
    document.querySelector("#container .html5-video-player") ||
    document.querySelector(".html5-video-player");
  if (html5Player) {
    return html5Player;
  }

  const video = document.querySelector("video");
  if (video) {
    return (
      video.closest("#movie_player") ||
      video.closest(".html5-video-player") ||
      video.parentElement
    );
  }

  return null;
}

function ensureOverlayAttached() {
  if (!overlayElement) {
    return false;
  }

  const host = getOverlayHost();
  if (!host) {
    debugLog("No overlay host found");
    return false;
  }

  if (window.getComputedStyle(host).position === "static") {
    host.style.position = "relative";
  }

  if (overlayElement.parentElement !== host) {
    host.appendChild(overlayElement);
    debugLog("Reattached overlay to host", host.className || host.id || host.tagName);
  }

  return true;
}

function createInterface() {
  const host = getOverlayHost() || document.body;
  attachHoverTracking(host);
  if (host !== document.body && window.getComputedStyle(host).position === "static") {
    host.style.position = "relative";
  }

  if (document.getElementById("overlay-element")) {
    overlayElement = document.getElementById("overlay-element");
    ensureOverlayAttached();
    ensureLaneContainers();
    applyOverlayStyles();
    updateLaneVisibility();
    updateEyeToggleVisibility();
    return;
  }

  overlayElement = document.createElement("div");
  overlayElement.id = "overlay-element";
  overlayElement.classList.add("overlay-root");
  ensureLaneContainers();
  applyOverlayStyles();
  updateLaneVisibility();

  host.appendChild(overlayElement);
  ensureOverlayAttached();
  updateEyeToggleVisibility();
}

function getMarkerContainer() {
  return (
    document.querySelector("#movie_player .ytp-timed-markers-container") ||
    document.querySelector("#movie_player .ytp-progress-list")
  );
}

function getOrCreateMarkerBar() {
  if (markerBarElement && markerBarElement.parentElement) {
    return markerBarElement;
  }

  const container = getMarkerContainer();
  if (!container) {
    return null;
  }

  markerBarElement = container.querySelector(".__kons-ts-marker-bar");
  if (!markerBarElement) {
    markerBarElement = document.createElement("div");
    markerBarElement.className = "__kons-ts-marker-bar";
    container.appendChild(markerBarElement);
  }

  return markerBarElement;
}

function clearMarkers() {
  if (markerBarElement) {
    markerBarElement.innerHTML = "";
  }
  hideMarkerPreview();
}

function getOrCreateMarkerPreview() {
  if (markerPreviewElement && markerPreviewElement.parentElement) {
    return markerPreviewElement;
  }

  const host = getOverlayHost();
  if (!host) {
    return null;
  }

  markerPreviewElement = host.querySelector(".__kons-ts-marker-preview");
  if (!markerPreviewElement) {
    markerPreviewElement = document.createElement("div");
    markerPreviewElement.className = "__kons-ts-marker-preview";
    markerPreviewElement.style.display = "none";
    host.appendChild(markerPreviewElement);
  }
  return markerPreviewElement;
}

function showMarkerPreview(markerRect, markerData) {
  const preview = getOrCreateMarkerPreview();
  const host = getOverlayHost();
  if (!preview || !host) {
    return;
  }

  const sample = markerData.comments[0];
  preview.textContent = sample?.text || "";
  preview.style.display = "block";

  const hostRect = host.getBoundingClientRect();
  const centerX = markerRect.left + markerRect.width / 2;
  const previewWidth = Math.min(420, hostRect.width - 16);
  preview.style.width = `${previewWidth}px`;

  const desiredLeft = centerX - hostRect.left - previewWidth / 2;
  const clampedLeft = Math.max(8, Math.min(hostRect.width - previewWidth - 8, desiredLeft));
  preview.style.left = `${clampedLeft}px`;
}

function hideMarkerPreview() {
  if (markerPreviewElement) {
    markerPreviewElement.style.display = "none";
  }
}

function renderHeatmapWave(bar, videoDuration) {
  if (!bar) {
    return;
  }
  let wave = bar.querySelector(".__kons-ts-heatmap-wave");

  if (
    !heatmapEnabled ||
    !Number.isFinite(videoDuration) ||
    videoDuration <= 0 ||
    comments.length === 0
  ) {
    if (wave) {
      wave.remove();
    }
    return;
  }
  if (!wave) {
    wave = document.createElement("div");
    wave.className = "__kons-ts-heatmap-wave";
    bar.appendChild(wave);
  } else {
    wave.innerHTML = "";
  }

  const bins = 420;
  const counts = new Array(bins).fill(0);
  for (const comment of comments) {
    if (comment.time < 0 || comment.time > videoDuration) {
      continue;
    }
    const ratio = comment.time / videoDuration;
    const idx = Math.min(bins - 1, Math.max(0, Math.floor(ratio * bins)));
    counts[idx] += 1;
  }
  const weights = [1, 2, 3, 4, 5, 6, 7, 8, 9, 8, 7, 6, 5, 4, 3, 2, 1];
  const radius = Math.floor(weights.length / 2);
  const applyKernelSmoothing = (source) =>
    source.map((_, idx) => {
      let total = 0;
      let weightSum = 0;
      for (let offset = -radius; offset <= radius; offset += 1) {
        const current = idx + offset;
        if (current < 0 || current >= bins) {
          continue;
        }
        const weight = weights[offset + radius];
        total += source[current] * weight;
        weightSum += weight;
      }
      return weightSum ? total / weightSum : 0;
    });

  const smoothed = applyKernelSmoothing(counts);
  const smoothedTwice = applyKernelSmoothing(smoothed);
  const smoothedThrice = applyKernelSmoothing(smoothedTwice);
  const smoothedValues = smoothedThrice;

  const maxCount = Math.max(...smoothedValues);
  if (!maxCount) {
    wave.remove();
    return;
  }

  const globalIntensity =
    clamp(heatmapIntensity, MIN_HEATMAP_INTENSITY, MAX_HEATMAP_INTENSITY) / 100;
  const intensityScale = Math.pow(globalIntensity, 0.82);
  const maxHeightPx = 18;
  const minHeightPx = 2;
  const fragment = document.createDocumentFragment();
  for (let i = 0; i < bins; i += 1) {
    const ratio = smoothedValues[i] / maxCount;
    const eased = Math.pow(ratio, 0.72);
    const height = minHeightPx + eased * maxHeightPx * intensityScale;
    const alpha = clamp(
      0.18 + eased * (0.28 + 0.55 * Math.min(1, intensityScale / 3)),
      0.08,
      0.98
    );

    const bin = document.createElement("span");
    bin.className = "__kons-ts-heatmap-bin";
    bin.style.height = `${height.toFixed(2)}px`;
    bin.style.opacity = alpha.toFixed(3);
    fragment.appendChild(bin);
  }
  wave.appendChild(fragment);
}

function renderTimeMarkers() {
  const video = getVideo();
  if (!video || !Number.isFinite(video.duration) || video.duration <= 0) {
    if (video) {
      video.addEventListener(
        "loadedmetadata",
        () => {
          renderTimeMarkers();
        },
        { once: true }
      );
    }
    return;
  }

  const bar = getOrCreateMarkerBar();
  if (!bar) {
    return;
  }
  bar.innerHTML = "";
  renderHeatmapWave(bar, video.duration);

  const groupedByTime = new Map();
  for (const comment of comments) {
    if (!groupedByTime.has(comment.time)) {
      groupedByTime.set(comment.time, []);
    }
    groupedByTime.get(comment.time).push(comment);
  }

  const entries = [...groupedByTime.entries()].sort((a, b) => a[0] - b[0]);
  entries.forEach(([time, groupedComments]) => {
    if (time > video.duration) {
      return;
    }
    groupedComments.sort(compareByPriority);

    const marker = document.createElement("div");
    marker.className = "__kons-ts-marker";
    const hasDiamondTier = groupedComments.some(
      (comment) => Number(comment?.likes || 0) > 0 && Number(comment?.likes || 0) >= diamondLikedThreshold
    );
    const hasGoldTier = groupedComments.some(
      (comment) => Number(comment?.likes || 0) > 0 && Number(comment?.likes || 0) >= topLikedThreshold
    );
    if (hasDiamondTier) {
      marker.classList.add("diamond-tier");
    } else if (hasGoldTier) {
      marker.classList.add("gold-tier");
    }
    const offset = (time / video.duration) * 100;
    marker.style.left = `${offset}%`;

    const markerData = { time, comments: groupedComments };
    marker.title = `${formatTime(time)} • ${groupedComments.length} comment(s)`;

    marker.addEventListener("mouseenter", () => {
      showMarkerPreview(marker.getBoundingClientRect(), markerData);
    });
    marker.addEventListener("mouseleave", () => {
      hideMarkerPreview();
    });
    marker.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const currentVideo = getVideo();
      if (currentVideo) {
        currentVideo.currentTime = time;
      }
    });

    bar.appendChild(marker);
  });
}

function startMonitoring() {
  monitoringInitialized = true;
  const video = document.querySelector("video");
  videoContainer = getOverlayHost() || document.querySelector("#container .html5-video-player");

  if (!video) {
    return;
  }

  video.ontimeupdate = () => {
    if (isAdPlaying()) {
      return;
    }
    scheduleReconcile(video.currentTime);
  };

  video.onseeking = () => {
    if (isAdPlaying()) {
      return;
    }
    scheduleReconcile(video.currentTime);
    debugLog("Seek reconcile", video.currentTime);
  };

  video.onseeked = () => {
    if (isAdPlaying()) {
      return;
    }
    scheduleReconcile(video.currentTime);
  };

  video.onplay = () => {
    if (isAdPlaying()) {
      return;
    }
    scheduleReconcile(video.currentTime);
  };
}

function removeCardState(cardState) {
  const index = activeCards.indexOf(cardState);
  if (index >= 0) {
    activeCards.splice(index, 1);
  }
  if (cardState?.commentId) {
    activeCardByCommentId.delete(cardState.commentId);
  }
}

function beginCardHide(cardState) {
  if (!cardState || cardState.phase !== "visible") {
    removeCardState(cardState);
    return;
  }
  if (!cardState.card.isConnected) {
    removeCardState(cardState);
    return;
  }

  cardState.phase = "hiding";
  cardState.card.classList.remove("visible");
  cardState.card.classList.add("hiding");

  setTimeout(() => {
    if (cardState.card.parentElement) {
      cardState.card.remove();
    }
    removeCardState(cardState);
  }, 320);
}

function isAdPlaying() {
  const adPlaying = Boolean(
    videoContainer &&
      (videoContainer.classList.contains("ad-showing") ||
        videoContainer.classList.contains("ad-interrupting"))
  );
  if (adPlaying) {
    hideOverlay();
  }
  return adPlaying;
}

function reconcileVisibleComments(currentTime) {
  if (!isActive || notificationsMutedByEye || !overlayElement) {
    setUpcomingDotVisible(false);
    return;
  }
  if (!ensureOverlayAttached()) {
    setUpcomingDotVisible(false);
    return;
  }

  const visibleKeys = new Set();
  let hasUpcomingWarning = false;
  const pendingToShow = [];
  const playbackRate = getActivePlaybackRate();

  for (const comment of comments) {
    const triggerTime = earlyModeEnabled
      ? Math.max(0, comment.time - earlySeconds)
      : comment.time;
    const warningTime = Math.max(0, triggerTime - 3);

    if (currentTime >= warningTime && currentTime < triggerTime) {
      hasUpcomingWarning = true;
    }

    const commentVisibleDuration = getCommentDisplayDurationSeconds(comment, playbackRate);
    if (currentTime >= triggerTime && currentTime < comment.time + commentVisibleDuration) {
      const commentKey = getCommentKey(comment);
      visibleKeys.add(commentKey);

      if (!activeCardByCommentId.has(commentKey)) {
        pendingToShow.push(comment);
      }
    }
  }

  pendingToShow.sort((a, b) => {
    const triggerA = earlyModeEnabled ? Math.max(0, a.time - earlySeconds) : a.time;
    const triggerB = earlyModeEnabled ? Math.max(0, b.time - earlySeconds) : b.time;
    if (triggerA !== triggerB) {
      return triggerA - triggerB;
    }
    return compareByPriority(a, b);
  });

  for (const comment of pendingToShow) {
    const accentDelayMs = Math.max(0, (comment.time - currentTime) * 1000);
    showOverlay(comment, accentDelayMs);
  }

  for (const cardState of [...activeCards]) {
    if (!visibleKeys.has(cardState.commentId)) {
      beginCardHide(cardState);
    }
  }

  const shouldShowWarningDot = hasUpcomingWarning && activeCards.length === 0;
  setUpcomingDotVisible(shouldShowWarningDot);
}

function showOverlay(comment, accentDelayMs = 0) {
  if (!overlayElement || !isActive) {
    return;
  }
  if (!ensureOverlayAttached()) {
    return;
  }
  const commentId = getCommentKey(comment);
  if (activeCardByCommentId.has(commentId)) {
    return;
  }
  const targetCorner = resolveCommentCorner(comment);
  const lane = getLaneElement(targetCorner);
  if (!lane) {
    return;
  }

  const card = document.createElement("div");
  card.className = "overlay-comment";
  const likesCount = Number(comment?.likes || 0);
  const tierRank = getTierRank(likesCount);
  if (tierRank >= 2) {
    card.classList.add("diamond-liked");
  } else if (tierRank >= 1) {
    card.classList.add("top-liked");
  }
  card.style.order = String(getTierOrderForCorner(targetCorner, tierRank));
  card.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    seekToCommentContext(comment, 2);
  });

  const avatar = document.createElement("img");
  avatar.className = "comment-avatar";
  avatar.src = comment.avatar;

  const content = document.createElement("div");
  content.className = "comment-content";

  const textElement = document.createElement("span");
  textElement.className = "comment-text";

  const renderedText = comment.text.replace(
    /(\d{1,}):([0-5]\d)(?::([0-5]\d))?/g,
    "<strong>$&</strong>"
  );

  textElement.innerHTML = renderedText;
  content.appendChild(textElement);
  if (showLikesInNotifications) {
    const likesCount = Number(comment?.likes || 0);
    if (likesCount > 0) {
      const likesElement = document.createElement("span");
      likesElement.className = "comment-likes";
      likesElement.textContent = `Likes ${formatLikesLabel(likesCount)}`;
      content.appendChild(likesElement);
    }
  }
  card.append(avatar, content);
  const isTopCorner = targetCorner === "top-left" || targetCorner === "top-right";
  const shouldPrepend = isTopCorner !== reverseStackOrder;
  if (shouldPrepend) {
    lane.prepend(card);
  } else {
    lane.appendChild(card);
  }

  requestAnimationFrame(() => {
    card.classList.add("visible");
  });
  const playbackRate = getActivePlaybackRate();

  if (earlyModeEnabled && timestampAccentEffect !== "none") {
    const effectClass = `accent-${timestampAccentEffect}`;
    const delay = Math.max(0, Math.min(getDisplayDurationMs(comment, playbackRate), accentDelayMs));
    setTimeout(() => {
      card.classList.add(effectClass);
      setTimeout(() => {
        card.classList.remove(effectClass);
      }, 1300);
    }, delay);
  }
  const cardState = {
    commentId,
    card,
    phase: "visible",
    remainingMs: getDisplayDurationMs(comment, playbackRate),
    hideTimeoutId: null,
    hideStartedAt: Date.now()
  };
  activeCards.push(cardState);
  activeCardByCommentId.set(commentId, cardState);
}

function hideOverlay() {
  if (!overlayElement) {
    return;
  }
  for (const cardState of activeCards) {
    if (cardState.hideTimeoutId) {
      clearTimeout(cardState.hideTimeoutId);
      cardState.hideTimeoutId = null;
    }
  }
  activeCards = [];
  activeCardByCommentId.clear();
  if (upcomingDotElement && upcomingDotElement.parentElement) {
    upcomingDotElement.remove();
  }
  upcomingDotElement = null;
  overlayElement.querySelectorAll(".overlay-comment").forEach((card) => {
    card.remove();
  });
}

function changePosition(newPosition) {
  if (!overlayElement) {
    return;
  }
  position = newPosition;
  updateLaneVisibility();
  updateEyeToggleVisibility();
  setUpcomingDotVisible(false);
}

async function getCommentPosition() {
  const value = await chrome.storage.sync.get("position");
  return value?.position ? value.position : "bottom-left";
}

function getTimeInSeconds(timestampText) {
  let total = 0;
  try {
    const parts = timestampRegex.exec(timestampText)[0].split(":").reverse();
    if (parts[0]) {
      total += parseInt(parts[0], 10);
    }
    if (parts[1]) {
      total += parseInt(parts[1], 10) * 60;
    }
    if (parts[2]) {
      total += parseInt(parts[2], 10) * 3600;
    }
  } catch (error) {
    return null;
  }
  return total;
}

async function isActiveFunc() {
  const value = await chrome.storage.sync.get("active");
  return value?.active === undefined || value?.active === null || value.active;
}

function resetVariables() {
  monitoringInitialized = false;
  comments = [];
  activeCards = [];
  activeCardByCommentId = new Map();
  if (eyeToggleElement && eyeToggleElement.parentElement) {
    eyeToggleElement.remove();
  }
  upcomingDotElement = null;
  eyeToggleElement = null;
  isVideoHovering = false;
  reconcileRafId = null;
  pendingReconcileTime = null;
  renderMarkersRafId = null;
  laneElements = new Map();
  topLikedThreshold = 0;
  diamondLikedThreshold = Number.POSITIVE_INFINITY;
  clearMarkers();
  hideOverlay();
}

window.addEventListener("load", async () => {
  await main();
});

locationChange(() => {
  main();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  sendResponse(true);

  if (message.type === "position") {
    changePosition(message.newPosition);
    const video = getVideo();
    if (video && !isAdPlaying()) {
      scheduleReconcile(video.currentTime);
    }
    return;
  }

  if (message.type === "isActive") {
    isActive = message.status;
    if (!isActive) {
      hideOverlay();
    } else {
      const video = getVideo();
      if (video) {
        scheduleReconcile(video.currentTime);
      }
    }
    updateEyeToggleVisibility();
    return;
  }

  if (message.type === "overlaySettings") {
    overlayScale = clamp(
      Number(message.overlayScale ?? overlayScale),
      MIN_OVERLAY_SCALE,
      MAX_OVERLAY_SCALE
    );
    displayDuration = clamp(
      Number(message.displayDuration ?? displayDuration),
      MIN_DISPLAY_DURATION,
      MAX_DISPLAY_DURATION
    );
    overlayRadius = clamp(
      Number(message.overlayRadius ?? overlayRadius),
      MIN_OVERLAY_RADIUS,
      MAX_OVERLAY_RADIUS
    );
    overlayAvatarSize = clamp(
      Number(message.overlayAvatarSize ?? overlayAvatarSize),
      MIN_OVERLAY_AVATAR_SIZE,
      MAX_OVERLAY_AVATAR_SIZE
    );
    overlayGlassiness = clamp(
      Number(message.overlayGlassiness ?? overlayGlassiness),
      MIN_OVERLAY_GLASSINESS,
      MAX_OVERLAY_GLASSINESS
    );
    overlayDarkness = clamp(
      Number(message.overlayDarkness ?? overlayDarkness),
      MIN_OVERLAY_DARKNESS,
      MAX_OVERLAY_DARKNESS
    );
    debugMode = Boolean(message.debugMode ?? debugMode);
    earlyModeEnabled = Boolean(message.earlyModeEnabled ?? earlyModeEnabled);
    followPlaybackSpeed = Boolean(message.followPlaybackSpeed ?? followPlaybackSpeed);
    earlySeconds = clamp(
      Number(message.earlySeconds ?? earlySeconds),
      MIN_EARLY_SECONDS,
      MAX_EARLY_SECONDS
    );
    timestampAccentEffect = String(message.timestampAccentEffect ?? timestampAccentEffect);
    reverseStackOrder = Boolean(message.reverseStackOrder ?? reverseStackOrder);
    priorityScoringEnabled = Boolean(
      message.priorityScoringEnabled ?? priorityScoringEnabled
    );
    priorityLikesWeight = clamp(
      Number(message.priorityLikesWeight ?? priorityLikesWeight),
      MIN_PRIORITY_LIKES_WEIGHT,
      MAX_PRIORITY_LIKES_WEIGHT
    );
    topLikedThresholdPercent = clamp(
      Number(message.topLikedThresholdPercent ?? topLikedThresholdPercent),
      MIN_TOP_LIKED_THRESHOLD_PERCENT,
      MAX_TOP_LIKED_THRESHOLD_PERCENT
    );
    heatmapEnabled = Boolean(message.heatmapEnabled ?? heatmapEnabled);
    heatmapIntensity = clamp(
      Number(message.heatmapIntensity ?? heatmapIntensity),
      MIN_HEATMAP_INTENSITY,
      MAX_HEATMAP_INTENSITY
    );
    routingEnabled = Boolean(message.routingEnabled ?? routingEnabled);
    routingThreshold = clamp(
      Number(message.routingThreshold ?? routingThreshold),
      MIN_ROUTING_THRESHOLD,
      MAX_ROUTING_THRESHOLD
    );
    routingShortCorner = normalizeCorner(
      String(message.routingShortCorner ?? routingShortCorner),
      routingShortCorner
    );
    routingLongCorner = normalizeCorner(
      String(message.routingLongCorner ?? routingLongCorner),
      routingLongCorner
    );
    showLikesInNotifications = Boolean(
      message.showLikesInNotifications ?? showLikesInNotifications
    );
    recomputeLikeTierThresholds();
    applyOverlayStyles();
    scheduleRenderTimeMarkers();
    const video = getVideo();
    if (video && !isAdPlaying()) {
      scheduleReconcile(video.currentTime);
    }
    updateEyeToggleVisibility();
    return;
  }

  if (message.type === "comments_filter_settings_changed") {
    debugLog("Comment filter changed, force refreshing comments");
    const videoId = getVideoId();
    if (videoId) {
      chrome.runtime.sendMessage({ type: "comments", video_id: videoId, forceRefresh: true });
    }
    return;
  }

  if (message.type === "comments_replace") {
    comments = message.comments || [];
    comments.sort((a, b) => {
      if (a.time !== b.time) {
        return a.time - b.time;
      }
      return compareByPriority(a, b);
    });
    recomputeLikeTierThresholds();
    hideOverlay();
    scheduleRenderTimeMarkers();
    if (monitoringInitialized === false) {
      startMonitoring();
    }
    const video = getVideo();
    if (video && !isAdPlaying()) {
      scheduleReconcile(video.currentTime);
    }
    return;
  }

  if (message.type === "comments_update") {
    comments.push(...(message.comments || []));
    comments.sort((a, b) => {
      if (a.time !== b.time) {
        return a.time - b.time;
      }
      return compareByPriority(a, b);
    });
    recomputeLikeTierThresholds();
    scheduleRenderTimeMarkers();
    if (monitoringInitialized === false) {
      startMonitoring();
    }
    const video = getVideo();
    if (video && !isAdPlaying()) {
      scheduleReconcile(video.currentTime);
    }
  }
});
